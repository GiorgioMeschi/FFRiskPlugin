QGIS plug-in for  WILDFIRE RISK ASSESSMENT 

focus on national and regional speditive analysis  

evaluation of:
- wildfire susceptibility throught machine learning techniques 
- wildfire intensity "worst case scenario" based only on fuel type coverage
- wildfire Hazard throught a custom contingency matrix of the 2 previous products
- wildfire RISK considering different type of exposed elements (POI, fuel type, population density, roads)
- Wildfire exposed element specific risk - right now just for POI elements.

default values in the plug in take in consideration the usage of CORINE land cover and exposed elements
from OSM (POI, transports and roads).
The user has the possibility of using different input layers, specifing some details in the excel files in this repository
